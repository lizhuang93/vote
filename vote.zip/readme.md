### 1. 启动
```
npm install
npm run dev

http://localhost:3000
```

### 参考文档
https://juejin.cn/post/6980142557066067982


